The XML Message Server

File List
=========
Config.java
Message.java
MessageServer.java
MessageServerClient.java
MyClientDel.java
MyClientPut.java
MyClientGet.java
QueueManager.java
sortitem.xsl
setclass.bat
setpath.bat

Getting Started
===============
* You will need to download the xml parser from http://xml.apache.org/
* place xalan.jar and xerces.jar in your classpath
* ensure that your path points to your JDK
* Place (MessageServer) files in a directory in your classpath
* The server can be started by typing "java MessageServer"
* You can use the sample clients MyClientPut, MyClientGet, MyClientDel or
you can write your own using MessageServerClient to communicate with the MessageServer


