import javax.xml.transform.*;
import org.apache.xerces.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import org.apache.xml.serialize.*;
import org.apache.xerces.dom.*;
import org.apache.xalan.xslt.*;

import java.io.*;
import java.util.*;
import org.apache.xerces.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import org.apache.xml.serialize.*;
import org.apache.xerces.dom.*;
 
public class Config {
	private String status = null;
	private String command = null;
	private String queueName = null;
	private String messageId = null;
	private String payload = null;
	private String processingRule = null;
	
	final static String STATUS_OK = "OK";
	final static String STATUS_DUPLICATE = "DU";
	final static String STATUS_NOT_FOUND = "NF";
	final static String STATUS_ERROR = "ER";
	final static String STATUS_IO = "IO";
	final static String STATUS_QUEUE_NOT_FOUND = "QN";
	final static String STATUS_INVALID_COMMAND = "IC";

	final static String COMMAND_PUT = "PUT";
	final static String COMMAND_GET = "GET";
	final static String COMMAND_DELETE = "DEL";

	private Document doc;
	private Element elementMessage; 
	private Element elementHeader; 
	private Element elementStatus; 
	private Element elementCommand; 
	private Element elementQueueName; 
	private Element elementPayload;
	private Element elementMessageId; 
	private Element elementProcessingRule;  

public Config(String fileName) throws FileNotFoundException {
	FileInputStream fis = new FileInputStream(fileName);
	InputSource     in  = new InputSource(fis);
	
	DOMParser parser = new DOMParser();
	try {
		parser.parse(in);
	} catch (Exception e) {
		System.out.println("Config:Config:1:" + e.toString());
	}
	doc = parser.getDocument();
}
public boolean getLog() {
	NodeList nl = doc.getElementsByTagName("log");
	Node n = nl.item(0).getFirstChild();
	
	if (n.getNodeValue().equals("1")) {
		return true;
	} else {
		return false;
	}
}
public int getPort() {
	NodeList nl = doc.getElementsByTagName("port");
	Node n = nl.item(0).getFirstChild();
	return Integer.parseInt(n.getNodeValue());
}
public String[] getQueues() {
	NodeList nl = doc.getElementsByTagName("queue");
	int numberOfQueues = nl.getLength();
	
	String queues[] = new String[numberOfQueues];
	
	for (int i = 0; i < numberOfQueues; i++) {
		queues[i] = (nl.item(i).getFirstChild().getNodeValue());
	}
	
	return queues;
}
public String toString() {
	StringWriter sr = null;
	try {
		OutputFormat format = new OutputFormat(doc);
		sr = new StringWriter();
		XMLSerializer s = new XMLSerializer(sr, format);
		s.asDOMSerializer();
		s.serialize(doc.getDocumentElement());
	} catch (Exception e) {
		System.out.println("Config:toString:1:" + e.toString());
	}
	return sr.toString();
}
}
