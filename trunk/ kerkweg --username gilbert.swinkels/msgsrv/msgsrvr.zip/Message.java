import java.io.*;
import java.util.*;
import org.apache.xerces.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import org.apache.xml.serialize.*;
import org.apache.xerces.dom.*;
 
public class Message {
	private String status = null;
	private String command = null;
	private String queueName = null;
	private String messageId = null;
	private String payload = null;
	private String processingRule = null;
	
	final static String STATUS_OK = "OK";
	final static String STATUS_DUPLICATE = "DU";
	final static String STATUS_NOT_FOUND = "NF";
	final static String STATUS_ERROR = "ER";
	final static String STATUS_IO = "IO";
	final static String STATUS_QUEUE_NOT_FOUND = "QN";
	final static String STATUS_INVALID_COMMAND = "IC";

	final static String COMMAND_PUT = "PUT";
	final static String COMMAND_GET = "GET";
	final static String COMMAND_DELETE = "DEL";

	private Document doc;
	private Element elementMessage; 
	private Element elementHeader; 
	private Element elementStatus; 
	private Element elementCommand; 
	private Element elementQueueName; 
	private Element elementPayload;
	private Element elementMessageId; 
	private Element elementProcessingRule;  

public Message() {

	  doc = new DocumentImpl(); 

	  elementMessage = doc.createElement("message"); 
	  elementHeader = doc.createElement("header"); 

	  elementStatus = doc.createElement("status"); 
	  elementHeader.appendChild(elementStatus); 

	  elementCommand = doc.createElement("command"); 
	  elementHeader.appendChild(elementCommand); 

	  elementQueueName = doc.createElement("queueName"); 
	  elementHeader.appendChild(elementQueueName);

  	  elementMessageId = doc.createElement("messageId"); 
	  elementHeader.appendChild(elementMessageId);

  	  elementProcessingRule = doc.createElement("processingRule"); 
	  elementHeader.appendChild(elementProcessingRule); 

	  elementMessage.appendChild(elementHeader); 

	  elementPayload = doc.createElement("payload"); 
	  elementMessage.appendChild(elementPayload);
	  doc.appendChild(elementMessage);

}
public Message(String msg) {
	InputSource in = new InputSource(new StringReader(msg));
	DOMParser parser = new DOMParser();
	try {
		parser.parse(in);
	} catch (Exception e) {
		System.out.println("Message:Message:1:Unable to create DOM object");
	}
	doc = parser.getDocument();
}
public String getCommand() {
	NodeList nl = doc.getElementsByTagName("command");
	Node n = nl.item(0).getFirstChild();
	if (n == null) {
		return "";
	} else {
		return n.getNodeValue();
	}
}
public String getMessageId() {
	NodeList nl = doc.getElementsByTagName("messageId");
	Node n = nl.item(0).getFirstChild();
	if (n == null) {
		return "";
	} else {
		return n.getNodeValue();
	}
}
public String getPayload() {
        NodeList nl = doc.getElementsByTagName("payload");
        Node n = nl.item(0).getFirstChild();
	if (n == null) {
		return "";
	} else {
		return serializeNode(n);
	}
	
}
public String getProcessingRule() {
	NodeList nl = doc.getElementsByTagName("processingRule");
	Node n = nl.item(0).getFirstChild();
	if (n == null) {
		return "";
	} else {
		return n.getNodeValue();
	}
}
public String getQueueName() {
	NodeList nl = doc.getElementsByTagName("queueName");
		Node n = nl.item(0).getFirstChild();
	if (n == null) {
		return "";
	} else {
		return n.getNodeValue();
	}
}
public String getStatus() {
	NodeList nl = doc.getElementsByTagName("status");
	Node n = nl.item(0).getFirstChild();
	if (n == null) {
		return "";
	} else {
		return n.getNodeValue();
	}
}
public Element getXMLChildElement(String ParentName, String childName) {
	NodeList nlHeader = doc.getElementsByTagName(ParentName);
	NodeList nlStatus = ((Element) nlHeader.item(0)).getElementsByTagName(childName);
	return (Element) nlStatus.item(0);
}
public Element getXMLElement(String name) {
	NodeList nl = doc.getElementsByTagName(name);
	return (Element) nl.item(0);
}
public boolean isCommand(String s) {
	return getCommand().equals(s);
}
static public void main(String args[]) {

}
public void setCommand(String c) {
	setHeaderElement("command", c);;
}
public void setHeaderElement(String elementName, String elementValue) {
	Node elementHeader = getXMLElement("header");
	Element oldElement = getXMLChildElement("header", elementName);
	elementHeader.removeChild(oldElement);
	Element newElement = doc.createElement(elementName);
	elementHeader.appendChild(newElement);
	newElement.appendChild(doc.createTextNode(elementValue));
}
public void setMessageId(String m) {
	setHeaderElement("messageId", m);
}
public void setPayload(String p) {
		
	p = "<message><payload>"+p+"</payload></message>";

        //Build Payload as a Document	  
        InputSource in = new InputSource(new StringReader(p));
	DOMParser parser = new DOMParser();
	try {
	   parser.parse(in);
	} catch (Exception e) {
	   System.out.println("Message:setPayload:1:Unable to create DOM object");
	}
	Document docPayload = parser.getDocument();
	Element  elementPayload = docPayload.getDocumentElement();

	//Get root of message document
	Element firstRoot = doc.getDocumentElement();
	
	//Get root of payload document
	Element secondRoot = docPayload.getDocumentElement();
	
	//Get the Node to move
        NodeList kids = secondRoot.getElementsByTagName("payload");
        Element oneToMove = (Element)kids.item(0);

	//Get the Node to replace
        NodeList kids1 = firstRoot.getElementsByTagName("payload");
        Element oneToReplace = (Element)kids1.item(0);
	
       //Replace Node in the first document
       Node newOneToMove = doc.importNode(oneToMove, true);
       firstRoot.replaceChild(newOneToMove, oneToReplace);
    
}
public void setProcessingRule(String r) {

	setHeaderElement("processingRule", r);
}
public void setQueueName(String q) {
	setHeaderElement("queueName", q);
}
public void setStatus(String s) {
	setHeaderElement("status", s);
}
public String toString() {
	return serializeDoc(doc);
}

public String serializeDoc (Document doc) {
	StringWriter sr = null;
	try {
		OutputFormat format = new OutputFormat(doc);
		sr = new StringWriter();
		XMLSerializer s = new XMLSerializer(sr, format);
		s.asDOMSerializer();
		s.serialize(doc.getDocumentElement());
	} catch (Exception e) {
		System.out.println("Message:serializeDoc:1:" + e.toString());
	}
	return sr.toString();
}

public String serializeNode(Node node) 
  {
    String xml = "";
    int type = node.getNodeType();
    switch (type)
    {
      // print the document element
      case Node.DOCUMENT_NODE: 
        {
          xml += serializeNode(((Document)node).getDocumentElement());
          break;
        }

        // print element with attributes
      case Node.ELEMENT_NODE: 
        {
          xml += "<" +  node.getNodeName();
          NamedNodeMap attrs = node.getAttributes();
          for (int i = 0; i < attrs.getLength(); i++)
          {
            Node attr = attrs.item(i);
            xml += " " + attr.getNodeName() + 
                   "=\"" + attr.getNodeValue() + 
                   "\"";
          }
          xml += ">";

          NodeList children = node.getChildNodes();
          if (children != null)
          {
            int len = children.getLength();
            for (int i = 0; i < len; i++)
              xml += serializeNode(children.item(i));
          }

          break;
        }

        // handle entity reference nodes
      case Node.ENTITY_REFERENCE_NODE: 
        {
          xml += "&" + node.getNodeName() + ";";
          break;
        }

        // print cdata sections
      case Node.CDATA_SECTION_NODE: 
        {
          xml += "<![CDATA[" + node.getNodeValue() + "]]>";
          break;
        }

        // print text
      case Node.TEXT_NODE: 
        {
          xml += node.getNodeValue();
          break;
        }

        // print processing instruction
      case Node.PROCESSING_INSTRUCTION_NODE: 
        {
          xml += "<?";
          xml += node.getNodeName();
          String data = node.getNodeValue();
          {
            xml += " ";
            xml += data;
          }
          xml += "?>";
          break;
        }
    }

    if (type == Node.ELEMENT_NODE)
    {
      xml += "</" + node.getNodeName() + ">";
    }
    
    return xml;
  }

}
