import java.io.*;
import java.net.*;
import java.net.*;

public class MessageServerClient {
	private String command;
	private int portNumber;
	private String messageId;
	private String payload;
	private String otherHeader;
	private String processingRule;
	private String queueName;
	private String status;
	private String host;
	private static MessageServerClient instance;
	private Message reply;

private MessageServerClient() {
	super();
}
public static synchronized MessageServerClient getInstance() {
	if (instance == null)
		instance = new MessageServerClient();
	return instance;
}
public String getReplyCommand() {
	return reply.getCommand();
}
public String getReplyMessageId() {
	return reply.getMessageId();
}
public String getReplyPayload() {
	return reply.getPayload();
}
public String getReplyQueueName() {
	return reply.getQueueName();
}
public String getReplyStatus() {
	return reply.getStatus();
}
public String getSendCommand() {
	return command;
}
public String getSendHost() {
	return host;
}
public String getSendMessageId() {
	return messageId;
}
public String getSendPayload() {
	return payload;
}
public int getSendPortNumber() {
	return portNumber;
}
public String getSendProcessingRule() {
	return processingRule;
}
public String getSendQueueName() {
	return queueName;
}
public String getSendStatus() {
	return status;
}
public void send() throws IOException {
	Socket socket     = null;
	PrintWriter out   = null;
	BufferedReader in = null;

	socket = new Socket(host, portNumber);
	out    = new PrintWriter(socket.getOutputStream(), true);
	in     = new BufferedReader(new InputStreamReader(socket.getInputStream()));

	Message m = new Message();
	m.setStatus(status);
	m.setCommand(command);
	m.setQueueName(queueName);
	m.setProcessingRule(processingRule);
	m.setMessageId(messageId);
	m.setPayload(payload);
	
	//protocol stipulates that the the message
	//length will be followed by a new line character
	//which will be followed by the message
	out.println(m.toString().length()); 
	out.println(m.toString());

        //read server's reply
	StringBuffer sb = new StringBuffer();
	String line = in.readLine();
	while (line != null) {
		sb.append(line);
		line = in.readLine();
	}

        reply = new Message(sb.toString());
			
	out.close();
	in.close();
	socket.close();
}
public void setSendCommand(String newCommand) {
	command = newCommand;
}
public void setSendHost(String newHost) {
	host = newHost;
}
public void setSendMessageId(String newMessageId) {
	messageId = newMessageId;
}
public void setSendPayload(String newPayload) {
	payload = newPayload;
}
public void setSendPortNumber(int newPortNumber) {
	portNumber = newPortNumber;
}
public void setSendProcessingRule(String newProcessingRule) {
	processingRule = newProcessingRule;
}
public void setSendQueueName(String newQueueName) {
	queueName = newQueueName;
}
public void setSendStatus(String newStatus) {
	status = newStatus;
}
}
