/* The Queue Manager
   =================
   The socket is read into a string. The string is used to build a message
   object. The message object is interrogated to obtain the method. The
   Queue Manager then processes the appropriate method by adding/removing
   an object to/from the queue. If the GET method was invoked, the Queue manager
   is responsible for transmitting back to the client. The socket is closed.
*/
import java.util.*;
import java.net.*;
import java.io.*;

import org.apache.xerces.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import org.apache.xml.serialize.*;
import org.apache.xerces.dom.*;
import org.apache.xalan.xslt.*;

// Imported TraX classes
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.dom.DOMResult;

public class QueueManager extends Thread {
	private Socket socket;
	private Hashtable queue;
	private Hashtable queueContainer;
	transient private BufferedReader in;
	transient private OutputStream out;
	private boolean isLogging = false;
	private String status;
	
QueueManager(Hashtable queueContainer, Socket socket, boolean loggingSw) {
	isLogging = loggingSw;
	this.socket = socket;
	this.queueContainer = queueContainer;
	try {
		//in and out streams (from client)
		in  = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		out = socket.getOutputStream();
	} catch (Exception e) {
		status = Message.STATUS_IO;
		System.out.println("QueueManager:QueueManger:1:" + e.getMessage());
	}
}
public synchronized Message get(Message m) {
	status = Message.STATUS_OK;
	Message qm = (Message) queue.get(m.getMessageId());

	//apply client requested transformation rule
	if (m.getProcessingRule() != "" && qm != null) {
		try {
		qm = new Message(xslTransformation(qm.toString(), m.getProcessingRule()));
		} catch (Exception e) {
		System.out.println("QueueManager:get:1:" + e.toString());
		}
	}
	
	log("QueueManager: retrieved " + m.getMessageId() + " from " + m.getQueueName() + " queue");
        return qm;
        
}

public void log(String s) {
	if (isLogging == true) {System.out.println(s);};
	}

public static void main(String[] args) {}
private void purge(Message m) {
	status = Message.STATUS_OK;
	int i = queue.size();
	queue.clear();
	log("QueueManager: pruged all (" + i + ") messages from " + m.getQueueName() + " queue");
}
private synchronized void put(Message m) {
	if (queue.get(m.getMessageId()) == null) {
		status = Message.STATUS_OK;
		queue.put(m.getMessageId(), m);
		log("QueueManager: added     " + m.getMessageId() + " to " + m.getQueueName() + " queue");
	} else {
		status = Message.STATUS_DUPLICATE;
		log("QueueManager: duplicate " + m.getMessageId() + " to " + m.getQueueName() + " queue");
	}
}
private String readSocket() throws IOException {
	//first line contains the message length
	String line = in.readLine();
	int headerMessageLength = Integer.parseInt(line);
	
	//read lines from socket until the entire message length has been read
        StringBuffer sb = new StringBuffer();
	int incrementalMessageLength = 0;
	line = in.readLine();
        incrementalMessageLength += line.length() + 1;
	sb.append(line);

	while (incrementalMessageLength < headerMessageLength) {
                line = in.readLine();
     		incrementalMessageLength += line.length() + 1; //add 1 for new line char
		sb.append(line);
	}
        return sb.toString();
}
private synchronized void remove(Message m) {
	status = Message.STATUS_OK;
	queue.remove(m.getMessageId());
	log("QueueManager: removed   " + m.getMessageId() + " from " + m.getQueueName() + " queue");
	
}
public void run() {
	try {

		String msg = readSocket();
		Message inboundMessage = new Message(msg);

		//find the correct queue in the container
		if ((queue = (Hashtable) queueContainer.get(inboundMessage.getQueueName())) == null) {
		       Message outboundMessage = new Message();
		       outboundMessage.setStatus(Message.STATUS_QUEUE_NOT_FOUND);
		       writeSocket(outboundMessage.toString());
			
		//put message on queue
		} else if (inboundMessage.isCommand(Message.COMMAND_PUT)) {
			put(inboundMessage);
			Message outboundMessage = new Message();
			outboundMessage.setStatus(status);
			writeSocket(outboundMessage.toString());
			
		//get message from queue and remove it
		} else if (inboundMessage.isCommand(Message.COMMAND_GET)) {
			Message outboundMessage = get(inboundMessage);
			if (outboundMessage == null) {
				outboundMessage = new Message();
				outboundMessage.setStatus(Message.STATUS_NOT_FOUND);
			} else {
				outboundMessage.setStatus(status);
				remove(inboundMessage);
			}
			writeSocket(outboundMessage.toString());
							
		//purge the queue
		} else 	if (inboundMessage.isCommand(Message.COMMAND_DELETE)) {
			purge(inboundMessage);
			Message outboundMessage = new Message();
			outboundMessage.setStatus(status);
			writeSocket(outboundMessage.toString());

		//invalid command	
		} else {
			Message outboundMessage = new Message();
			outboundMessage.setStatus(Message.STATUS_INVALID_COMMAND);
			writeSocket(outboundMessage.toString());	
		}
		
		socket.close();
		
	} catch (Exception e) {
		System.out.println("QueueManager:run:1:" + e.toString());
	}
}
private void writeSocket(String msg) {
	try {
		byte[] b = msg.getBytes();
		out.write(b);
	} catch (Exception e) {
		System.out.println("QueueManager:writeSocket:1:Unable to write to socket");
	}
}


private String xslTransformation(String msg, String rule) 
               throws TransformerException, 
                      TransformerConfigurationException, 
                      FileNotFoundException, 
                      IOException {

	InputSource in        = new InputSource(new StringReader(msg));
	DOMParser   domParser = new DOMParser();

	//build DOM object
	try {
		domParser.parse(in);
	} catch (Exception e) {
		System.out.println("QueueManager:xslTransformation:1:" + e.toString());
	}
	
	Document docInput = domParser.getDocument();
	DOMSource ds = new DOMSource(docInput.getDocumentElement());
	DOMResult dr = new DOMResult();
  
	TransformerFactory tFactory = TransformerFactory.newInstance();
	Transformer transformer = tFactory.newTransformer(new StreamSource(rule + ".xsl"));
	transformer.transform(ds, dr);
	
	Document docTransform = (Document) dr.getNode();
		
	StringWriter sr = null;
	try {
		OutputFormat of = new OutputFormat(docTransform);
		sr = new StringWriter();
		XMLSerializer s = new XMLSerializer(sr, of);
		s.asDOMSerializer();
		s.serialize(docTransform.getDocumentElement());
	} catch (Exception e) {
		System.out.println("QueueManager:xslTransformation:2:" + e.toString());
	}
        log("QueueManager: XSLT performed");
  	return sr.toString();
}
}