

import java.io.*;
public class MyClientPut {

public MyClientPut() {
	super();
}
static public void main(String args[]) {
	MessageServerClient mc = MessageServerClient.getInstance();
        mc.setSendCommand(Message.COMMAND_PUT);
	mc.setSendHost("127.0.0.1");
	mc.setSendPortNumber(584);
	mc.setSendMessageId("0000001");
	mc.setSendPayload("<orders><order><itemNumber>83726</itemNumber><quantity>2</quantity><price>10.00</price></order><order><itemNumber>83432</itemNumber><quantity>2</quantity><price>10.00</price></order></orders>");
	mc.setSendProcessingRule("");
	mc.setSendQueueName("Q1");
	mc.setSendStatus(Message.STATUS_OK);
	
	try {
                mc.send();
                System.out.println("-----send------");
		System.out.println("send messageId:" + mc.getSendMessageId());
		System.out.println("send command..:" + mc.getSendCommand());
		System.out.println("send status...:" + mc.getSendStatus());
		System.out.println("send payload..:" + mc.getSendPayload());
		System.out.println("send queueName:" + mc.getSendQueueName());
		System.out.println("");
		System.out.println("-----reply-----");
		System.out.println("reply messageId:" + mc.getReplyMessageId());;
		System.out.println("reply command..:" + mc.getReplyCommand());
		System.out.println("reply status...:" + mc.getReplyStatus());
		System.out.println("reply payload..:" + mc.getReplyPayload());
		System.out.println("reply queueName:" + mc.getReplyQueueName());
	} catch (IOException e) {
		System.out.println("MyClient Error: IO Exception");
	} catch (Exception e) {
		System.out.println("MyClient Error:" + e.toString());
	}
}
}
