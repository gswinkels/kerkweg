/* Message Server
   ======================================
   When the server is created it will build the Container and place 
   the queues in the container. It will then continually check to see
   if a client socket has been created. If so, it creates an instance of
   the Queue Manager passing it the socket and the Container
*/
import java.io.*;
import java.net.*;
import java.util.*;

public class MessageServer extends Thread {
	ServerSocket serverSocket;
	static int PORTNUM;
	boolean loggingSw = false;
	static final Hashtable queueContainer = new Hashtable();

public MessageServer() {
	System.out.println("Message Server starting ...");
	Config c = null;
	
	try {
		c = new Config("config.xml");
	} catch (Exception e) {
		System.out.println("MessageServer:MessageServer:1:" + e.toString());
	}

	//set port number
	PORTNUM = c.getPort();
	System.out.println("Port is " + PORTNUM);

	//set logging switch
	loggingSw = c.getLog();
	System.out.println("Log switch is " + loggingSw);

	//build queues
	String[] queues = c.getQueues();
	for (int i = 0; i < queues.length; i++) {
		queueContainer.put(queues[i], new Hashtable());
		System.out.println("Queue " + queues[i] + " has been created");
	}
	
	try {
		//bind to server socket
		serverSocket = new ServerSocket(PORTNUM);
		System.out.println("MomServer: Message Server is running");
	} catch (IOException e) {
		System.out.println("MessageServer:MessageServer:2:could not create server socket");
		System.exit(1);
	}
}
public static void main(java.lang.String[] args) {
	
	MessageServer server = new MessageServer();

	// start up server thread
	server.start();
}
public void run() {
	Socket clientSocket = null;
	
	while (true) {

		//get out when not bound to server socket
		if (serverSocket == null) return;
		
		try {

			//listen to sever port. Create socket to client
			clientSocket = serverSocket.accept();

			//create an instance of the Queue Manager to process request from client
			QueueManager qm = new QueueManager(queueContainer, clientSocket, loggingSw);
			qm.start();
			
			
		} catch (IOException e) {
			System.out.println("MessageServer:run:1:client socket error");
			System.exit(1);
		}
	}
}
}
